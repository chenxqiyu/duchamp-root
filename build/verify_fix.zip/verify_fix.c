/* 修复验证：以真实构建方式(-DTARGET_CONFIG_H)包含 common.h，
 * 断言 SLIDE_* 线性别名 == run2 实测正确值（编译期求值，clang 静态断言）。
 * 编译: aarch64-linux-android35-clang -fsyntax-only -Isrc \
 *        -DTARGET_CONFIG_H=\"targets/shennong/target.h\" verify_fix.c
 */
#include "common.h"

/* run2 (05:19:44) p0 profile 打印的正确线性别名:
 *   slide_logger=ffffff80a9fe29c8 bootid_data=ffffff80aa107448
 *   init_task=ffffff80a9fef600 root_tg=ffffff80aa1d7580 sysctl_bootid=ffffff80aa24a458
 * = P0_PAGE_OFFSET + P0_KERNEL_PHYS_LOAD + RVA
 */
_Static_assert(SLIDE_NFULNL_LOGGER == 0xffffff80a9fe29c8ULL,
               "slide_logger alias (delta 版公式会算成 0xffffff8029fe29c8)");
_Static_assert(SLIDE_LOGGERS_0_1 == 0xffffff80a9fe2918ULL, "loggers[1] alias");
_Static_assert(SLIDE_RANDOM_BOOT_ID_DATA == 0xffffff80aa107448ULL,
               "bootid_data alias (delta 版会算成 0xffffff802a107448)");
_Static_assert(SLIDE_INIT_TASK == 0xffffff80a9fef600ULL,
               "init_task alias (delta 版会算成 0xffffff8029fef600)");
_Static_assert(SLIDE_ROOT_TASK_GROUP == 0xffffff80aa1d7580ULL,
               "root_tg alias");
_Static_assert(SLIDE_SYSCTL_BOOTID == 0xffffff80aa24a458ULL,
               "sysctl_bootid alias");

/* 与 target.h 编译期宏逐位一致（防 include 顺序回退） */
_Static_assert(P0_DATA_ALIAS_CONST(KIMAGE_TEXT_BASE + INIT_TASK_OFF) ==
                   SLIDE_INIT_TASK,
               "common.h 与 target.h 的 P0_DATA_ALIAS_CONST 必须一致");

/* 运行时函数公式也必须是同一结果 */
_Static_assert(P0_PAGE_OFFSET + P0_KERNEL_PHYS_LOAD + INIT_TASK_OFF ==
                   0xffffff80a9fef600ULL,
               "p0_data_alias() 修复后的期望值");

int main(void) { return 0; }
